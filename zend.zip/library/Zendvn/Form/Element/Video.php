<?php

namespace Zendvn\Form\Element;

use Zend\Form\Element;

class Video extends Element
{

    protected $attributes = array(
        'type' => 'video',
    );
}
