<?php
namespace Zendvn\Event;

class Functions {
	
	public static function funcOne(){
		echo '<h3 style="color:red;font-weight:bold">eventOne - 03</h3>';
	}
	
	public function funcTwo(){
		echo '<h3 style="color:red;font-weight:bold">eventOne - 04</h3>';
	}
}