$(function(){
   alert('hello');
});
function showLogin(){
    alert('login');
}