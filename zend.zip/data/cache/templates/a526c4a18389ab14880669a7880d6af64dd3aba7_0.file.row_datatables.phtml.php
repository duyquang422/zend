<?php /* Smarty version 3.1.27, created on 2015-10-18 20:48:00
         compiled from "G:\xampp\htdocs\zend\module\Admin\view\admin\partial\row_datatables.phtml" */ ?>
<?php
/*%%SmartyHeaderCode:242505623e960a974a7_79578108%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a526c4a18389ab14880669a7880d6af64dd3aba7' => 
    array (
      0 => 'G:\\xampp\\htdocs\\zend\\module\\Admin\\view\\admin\\partial\\row_datatables.phtml',
      1 => 1442640641,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '242505623e960a974a7_79578108',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5623e960aa3424_71606336',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5623e960aa3424_71606336')) {
function content_5623e960aa3424_71606336 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '242505623e960a974a7_79578108';
?>
<th><span class="ttl-col"><?php echo '<?php ';?>echo $this->title; <?php echo '?>';?></span></th><?php }
}
?>