<?php
return array(
	'Admin\Controller\IndexController'	=>	__DIR__ . '/src/Admin/Controller/IndexController.php',
);