<?php

namespace News\Controller;

use Zend\View\Model\ViewModel;
use Zendvn\Controller\ActionController;
use Zendvn\System\Info;

class CategoryPostsController extends ActionController{

    public function indexAction(){
//        return $this->response;
    }

}