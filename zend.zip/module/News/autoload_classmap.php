<?php
return array(
	'News\Controller\IndexController'	=>	__DIR__ . '/src/Controller/IndexController.php',
    'News\Controller\PostsController'	=>	__DIR__ . '/src/Controller/PostsController.php',
    'News\Controller\CategoryPostsController'	=>	__DIR__ . '/src/Controller/CategoryPostsController.php'
);