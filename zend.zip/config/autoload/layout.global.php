<?php
return array(
	'module_layouts'	=> array(
			'Admin'		=> 'layout/backend',
            'Home'      => 'layout/frontend',
			'News'      => 'layout/news'
	),
);
